# keyalearn

A package to assist in my machine learning classes with quick functions for some common tasks done.

Stands on the giant shoulders of other packages.
