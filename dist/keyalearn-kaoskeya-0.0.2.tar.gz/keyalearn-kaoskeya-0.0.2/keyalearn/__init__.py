def hello(name):
  print("Hello {}".format(name) if name else "Hello World")
